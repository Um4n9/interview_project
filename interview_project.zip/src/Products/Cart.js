import React from "react";

const Cart = () => {
  return <div>This is cart</div>;
};

export default Cart;
